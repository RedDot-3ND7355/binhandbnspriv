﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MaterialSkin.Controls;
using MaterialSkin;
using System.IO;
using System.Diagnostics;

namespace LegacyBin
{
    public partial class Form1 : MaterialForm
    {
        private readonly MaterialSkinManager materialSkinManager;

        public static Form1 CurrentForm;

        public Form1()
        {
            CurrentForm = this;
            InitializeComponent();

            // Initialize MaterialSkinManager
            materialSkinManager = MaterialSkinManager.Instance;

            // Set this to false to disable backcolor enforcing on non-materialSkin components
            // This HAS to be set before the AddFormToManage()
            materialSkinManager.EnforceBackcolorOnAllComponents = true;

            // MaterialSkinManager properties
            materialSkinManager.AddFormToManage(this);
            materialSkinManager.Theme = MaterialSkinManager.Themes.DARK;
            materialSkinManager.ColorScheme = new ColorScheme(Primary.Indigo500, Primary.Indigo700, Primary.Indigo100, Accent.Pink200, TextShade.BLACK);
        }

        public void UpdateText(string text)
        {
            materialLabel1.Text = text;
            materialLabel1.Refresh();
        }

        string FilePath = "";
        string OutPath = "";
        private void materialButton1_Click(object sender, EventArgs e)
        {
            if (!isBusy)
            {
                OpenFileDialog openFileDialog = new OpenFileDialog();
                openFileDialog.Title = "Search for a bin file";
                openFileDialog.Filter = "bin files(*.bin)| *.bin";
                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    if (File.Exists(openFileDialog.FileName))
                    {
                        FilePath = openFileDialog.FileName;
                        materialButton2.Enabled = true;
                        materialButton3.Enabled = true;
                    }
                }
            }
            else
            {
                materialCard1.Visible = true;
            }
        }

        LegacyBin.BDat LegacyBinActor = new LegacyBin.BDat();
        bool isBusy = false;
        private void materialButton2_Click(object sender, EventArgs e)
        {
            if (!isBusy)
            {
                if (File.Exists(FilePath))
                {
                    Task.Delay(50).ContinueWith(delegate
                    {
                        using (BDat LegacyBinActor = new BDat())
                        {
                            isBusy = true;
                            Control.CheckForIllegalCrossThreadCalls = false;
                            UpdateText("Reading bin...");
                            OutPath = FilePath + ".files";
                            byte[] bytes = File.ReadAllBytes(FilePath);
                            MemoryStream byteBuff = new MemoryStream(bytes);
                            LegacyBinActor.bIntData = materialCheckbox1.Checked;
                            LegacyBinActor.Load(byteBuff, BDAT_TYPE.BDAT_BINARY, FilePath.Contains("64.bin"));

                            //var info = JsonConvert.SerializeObject(LegacyBinActor, new JsonSerializerSettings
                            //{
                            //    Formatting = Formatting.Indented,
                            //    ReferenceLoopHandling = ReferenceLoopHandling.Ignore,
                            //    NullValueHandling = NullValueHandling.Ignore,
                            //});
                            //File.WriteAllText(Application.ExecutablePath.Replace("LegacyBin.exe", "") + "\\debug.log", info);
                            

                            Directory.CreateDirectory(OutPath);
                            LegacyBinActor.DumpXML(OutPath, FilePath.Contains("64.bin"));
                            byteBuff.Close();
                            bytes = null;
                        }
                        GC.Collect();
                        UpdateText("Done!");
                        isBusy = false;
                    });
                }
            }
            else
            {
                materialCard1.Visible = true;
            }
        }

        private void materialButton4_Click(object sender, EventArgs e)
        {
            materialCard1.Visible = false;
        }

        private void materialButton3_Click(object sender, EventArgs e)
        {
            if (!isBusy)
            {
                if (Directory.Exists(OutPath))
                {
                    Task.Delay(50).ContinueWith(delegate
                    {
                        using (BDat LegacyBinActor = new BDat())
                        {
                            isBusy = true;
                            Control.CheckForIllegalCrossThreadCalls = false;
                            UpdateText("Reading bin...");
                            byte[] bytes = File.ReadAllBytes(FilePath);
                            MemoryStream byteBuff = new MemoryStream(bytes);
                            LegacyBinActor.bIntData = materialCheckbox1.Checked;
                            LegacyBinActor.Load(byteBuff, BDAT_TYPE.BDAT_BINARY, FilePath.Contains("64.bin"));
                            UpdateText("Reading xml...");
                            LegacyBinActor.loadAllXml(OutPath);
                            UpdateText("Verifying xml...");
                            LegacyBinActor.check();
                            UpdateText("Updating bin...");
                            LegacyBinActor.replaceDatFromXml(FilePath.Contains("64.bin"));
                            UpdateText("Saving bin...");
                            byteBuff.Close();
                            byteBuff = new MemoryStream();
                            LegacyBinActor.Save(byteBuff, BDAT_TYPE.BDAT_BINARY, FilePath.Contains("64.bin"));
                            bytes = byteBuff.ToArray();
                            File.WriteAllBytes(FilePath, bytes);
                            byteBuff.Close();
                            bytes = null;
                            Directory.Delete(OutPath, true);
                        }
                        GC.Collect();
                        UpdateText("Done!");
                        isBusy = false;
                    });
                }
            }
            else
            {
                materialCard1.Visible = true;
            }
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            Process.GetCurrentProcess().Kill();
        }
    }
}
